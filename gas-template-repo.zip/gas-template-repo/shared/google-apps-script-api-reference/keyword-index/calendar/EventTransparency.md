## EventTransparency

### Properties

- OPAQUE — Enum
- TRANSPARENT — Enum
