## Color

### Properties

- BLUE — Enum
- BROWN — Enum
- CHARCOAL — Enum
- CHESTNUT — Enum
- GRAY — Enum
- GREEN — Enum
- INDIGO — Enum
- LIME — Enum
- MUSTARD — Enum
- OLIVE — Enum
- ORANGE — Enum
- PINK — Enum
- PLUM — Enum
- PURPLE — Enum
- RED — Enum
- RED_ORANGE — Enum
- SEA_BLUE — Enum
- SLATE — Enum
- TEAL — Enum
- TURQOISE — Enum
- YELLOW — Enum
