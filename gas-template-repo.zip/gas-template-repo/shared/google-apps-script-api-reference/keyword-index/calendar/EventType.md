## EventType

### Properties

- DEFAULT — Enum
- BIRTHDAY — Enum
- FOCUS_TIME — Enum
- FROM_GMAIL — Enum
- OUT_OF_OFFICE — Enum
- WORKING_LOCATION — Enum
