## Visibility

### Properties

- CONFIDENTIAL — Enum
- DEFAULT — Enum
- PRIVATE — Enum
- PUBLIC — Enum
