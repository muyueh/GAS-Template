## FolderIterator

### Methods

- getContinuationToken() — String
- hasNext() — Boolean
- next() — Folder
