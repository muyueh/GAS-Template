## SectionHeaderItem

### Methods

- duplicate() — SectionHeaderItem
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getTitle() — String
- getType() — ItemType
- setHelpText(text) — SectionHeaderItem
- setTitle(title) — SectionHeaderItem
