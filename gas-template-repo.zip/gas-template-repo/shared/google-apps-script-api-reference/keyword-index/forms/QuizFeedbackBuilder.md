## QuizFeedbackBuilder

### Methods

- addLink(url) — QuizFeedbackBuilder
- addLink(url, displayText) — QuizFeedbackBuilder
- build() — QuizFeedback
- copy() — QuizFeedbackBuilder
- setText(text) — QuizFeedbackBuilder
