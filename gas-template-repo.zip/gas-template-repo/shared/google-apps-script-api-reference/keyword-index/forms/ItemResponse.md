## ItemResponse

### Methods

- getFeedback() — Object
- getItem() — Item
- getResponse() — Object
- getScore() — Object
- setFeedback(feedback) — ItemResponse
- setScore(score) — ItemResponse
