## Choice

### Methods

- getGotoPage() — PageBreakItem
- getPageNavigationType() — PageNavigationType
- getValue() — String
- isCorrectAnswer() — Boolean
