## DurationItem

### Methods

- createResponse(hours, minutes, seconds) — ItemResponse
- duplicate() — DurationItem
- getGeneralFeedback() — QuizFeedback
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getPoints() — Integer
- getTitle() — String
- getType() — ItemType
- isRequired() — Boolean
- setGeneralFeedback(feedback) — DurationItem
- setHelpText(text) — DurationItem
- setPoints(points) — DurationItem
- setRequired(enabled) — DurationItem
- setTitle(title) — DurationItem
