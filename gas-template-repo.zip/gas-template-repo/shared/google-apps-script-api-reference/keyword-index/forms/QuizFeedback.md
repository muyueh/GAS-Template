## QuizFeedback

### Methods

- getLinkUrls() — String[]
- getText() — String
