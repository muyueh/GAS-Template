## ImageItem

### Methods

- duplicate() — ImageItem
- getAlignment() — Alignment
- getHelpText() — String
- getId() — Integer
- getImage() — Blob
- getIndex() — Integer
- getTitle() — String
- getType() — ItemType
- getWidth() — Integer
- setAlignment(alignment) — ImageItem
- setHelpText(text) — ImageItem
- setImage(image) — ImageItem
- setTitle(title) — ImageItem
- setWidth(width) — ImageItem
