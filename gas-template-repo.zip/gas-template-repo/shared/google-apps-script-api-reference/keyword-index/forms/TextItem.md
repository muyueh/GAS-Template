## TextItem

### Methods

- clearValidation() — TextItem
- createResponse(response) — ItemResponse
- duplicate() — TextItem
- getGeneralFeedback() — QuizFeedback
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getPoints() — Integer
- getTitle() — String
- getType() — ItemType
- isRequired() — Boolean
- setGeneralFeedback(feedback) — TextItem
- setHelpText(text) — TextItem
- setPoints(points) — TextItem
- setRequired(enabled) — TextItem
- setTitle(title) — TextItem
- setValidation(validation) — TextItem
