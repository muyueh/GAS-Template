## ParagraphTextItem

### Methods

- clearValidation() — ParagraphTextItem
- createResponse(response) — ItemResponse
- duplicate() — ParagraphTextItem
- getGeneralFeedback() — QuizFeedback
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getPoints() — Integer
- getTitle() — String
- getType() — ItemType
- isRequired() — Boolean
- setGeneralFeedback(feedback) — ParagraphTextItem
- setHelpText(text) — ParagraphTextItem
- setPoints(points) — ParagraphTextItem
- setRequired(enabled) — ParagraphTextItem
- setTitle(title) — ParagraphTextItem
- setValidation(validation) — ParagraphTextItem
