## GridItem

### Methods

- clearValidation() — GridItem
- createResponse(responses) — ItemResponse
- duplicate() — GridItem
- getColumns() — String[]
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getRows() — String[]
- getTitle() — String
- getType() — ItemType
- isRequired() — Boolean
- setColumns(columns) — GridItem
- setHelpText(text) — GridItem
- setRequired(enabled) — GridItem
- setRows(rows) — GridItem
- setTitle(title) — GridItem
- setValidation(validation) — GridItem
