## PageBreakItem

### Methods

- duplicate() — PageBreakItem
- getGoToPage() — PageBreakItem
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getPageNavigationType() — PageNavigationType
- getTitle() — String
- getType() — ItemType
- setGoToPage(goToPageItem) — PageBreakItem
- setGoToPage(navigationType) — PageBreakItem
- setHelpText(text) — PageBreakItem
- setTitle(title) — PageBreakItem
