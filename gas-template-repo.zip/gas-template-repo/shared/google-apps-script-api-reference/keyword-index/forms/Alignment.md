## Alignment

### Properties

- LEFT — Enum
- CENTER — Enum
- RIGHT — Enum
