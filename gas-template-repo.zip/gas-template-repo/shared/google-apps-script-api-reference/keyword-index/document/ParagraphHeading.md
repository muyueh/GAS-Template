## ParagraphHeading

### Properties

- NORMAL — Enum
- HEADING1 — Enum
- HEADING2 — Enum
- HEADING3 — Enum
- HEADING4 — Enum
- HEADING5 — Enum
- HEADING6 — Enum
- TITLE — Enum
- SUBTITLE — Enum
