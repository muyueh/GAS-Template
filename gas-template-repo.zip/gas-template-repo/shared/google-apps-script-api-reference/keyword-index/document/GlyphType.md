## GlyphType

### Properties

- BULLET — Enum
- HOLLOW_BULLET — Enum
- SQUARE_BULLET — Enum
- NUMBER — Enum
- LATIN_UPPER — Enum
- LATIN_LOWER — Enum
- ROMAN_UPPER — Enum
- ROMAN_LOWER — Enum
