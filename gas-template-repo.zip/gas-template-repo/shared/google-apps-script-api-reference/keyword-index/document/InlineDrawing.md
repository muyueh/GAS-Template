## InlineDrawing

### Methods

- copy() — InlineDrawing
- getAltDescription() — String
- getAltTitle() — String
- getAttributes() — Object
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — InlineDrawing
- removeFromParent() — InlineDrawing
- setAltDescription(description) — InlineDrawing
- setAltTitle(title) — InlineDrawing
- setAttributes(attributes) — InlineDrawing
