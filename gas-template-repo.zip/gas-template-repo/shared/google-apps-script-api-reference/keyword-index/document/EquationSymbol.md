## EquationSymbol

### Methods

- copy() — EquationSymbol
- getAttributes() — Object
- getCode() — String
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — EquationSymbol
- removeFromParent() — EquationSymbol
- setAttributes(attributes) — EquationSymbol
