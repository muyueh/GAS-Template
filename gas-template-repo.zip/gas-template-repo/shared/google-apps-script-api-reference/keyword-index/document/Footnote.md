## Footnote

### Methods

- copy() — Footnote
- getAttributes() — Object
- getFootnoteContents() — FootnoteSection
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- removeFromParent() — Footnote
- setAttributes(attributes) — Footnote
