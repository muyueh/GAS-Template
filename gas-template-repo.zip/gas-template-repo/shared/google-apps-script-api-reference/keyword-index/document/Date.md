## Date

### Methods

- copy() — Date
- getAttributes() — Object
- getDisplayText() — String
- getLocale() — String
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getTimestamp() — Date
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — Date
- removeFromParent() — Date
- setAttributes(attributes) — Date
