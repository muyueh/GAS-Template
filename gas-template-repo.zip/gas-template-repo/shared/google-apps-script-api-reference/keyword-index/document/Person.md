## Person

### Methods

- copy() — Person
- getAttributes() — Object
- getEmail() — String
- getName() — String
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — Person
- removeFromParent() — Person
- setAttributes(attributes) — Person
