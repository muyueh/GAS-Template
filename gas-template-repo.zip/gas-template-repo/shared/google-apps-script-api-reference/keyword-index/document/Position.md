## Position

### Methods

- getElement() — Element
- getOffset() — Integer
- getSurroundingText() — Text
- getSurroundingTextOffset() — Integer
- insertBookmark() — Bookmark
- insertInlineImage(image) — InlineImage
- insertText(text) — Text
