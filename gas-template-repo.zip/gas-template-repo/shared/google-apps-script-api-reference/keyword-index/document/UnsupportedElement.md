## UnsupportedElement

### Methods

- copy() — UnsupportedElement
- getAttributes() — Object
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — UnsupportedElement
- removeFromParent() — UnsupportedElement
- setAttributes(attributes) — UnsupportedElement
