## DocumentApp

### Properties

- Attribute — Attribute
- ElementType — ElementType
- FontFamily — FontFamily
- GlyphType — GlyphType
- HorizontalAlignment — HorizontalAlignment
- ParagraphHeading — ParagraphHeading
- PositionedLayout — PositionedLayout
- TextAlignment — TextAlignment
- VerticalAlignment — VerticalAlignment

### Methods

- create(name) — Document
- getActiveDocument() — Document
- getUi() — Ui
- openById(id) — Document
- openByUrl(url) — Document
