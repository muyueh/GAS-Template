## Bookmark

### Methods

- getId() — String
- getPosition() — Position
- remove() — void
