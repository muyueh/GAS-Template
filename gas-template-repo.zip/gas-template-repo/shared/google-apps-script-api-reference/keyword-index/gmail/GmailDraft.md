## GmailDraft

### Methods

- deleteDraft() — void
- getId() — String
- getMessage() — GmailMessage
- getMessageId() — String
- send() — GmailMessage
- update(recipient, subject, body) — GmailDraft
- update(recipient, subject, body, options) — GmailDraft
