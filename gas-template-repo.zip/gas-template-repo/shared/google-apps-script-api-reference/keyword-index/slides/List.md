## List

### Methods

- getListId() — String
- getListParagraphs() — Paragraph[]
