## AutoText

### Methods

- getAutoTextType() — AutoTextType
- getIndex() — Integer
- getRange() — TextRange
