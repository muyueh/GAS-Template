## PageElementType

### Properties

- UNSUPPORTED — Enum
- SHAPE — Enum
- IMAGE — Enum
- VIDEO — Enum
- TABLE — Enum
- GROUP — Enum
- LINE — Enum
- WORD_ART — Enum
- SHEETS_CHART — Enum
- SPEAKER_SPOTLIGHT — Enum
