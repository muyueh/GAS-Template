## CellMergeState

### Properties

- NORMAL — Enum
- HEAD — Enum
- MERGED — Enum
