## Fill

### Methods

- getSolidFill() — SolidFill
- getType() — FillType
- isVisible() — Boolean
- setSolidFill(color) — void
- setSolidFill(color, alpha) — void
- setSolidFill(red, green, blue) — void
- setSolidFill(red, green, blue, alpha) — void
- setSolidFill(hexString) — void
- setSolidFill(hexString, alpha) — void
- setSolidFill(color) — void
- setSolidFill(color, alpha) — void
- setTransparent() — void
