## AutoTextType

### Properties

- UNSUPPORTED — Enum
- SLIDE_NUMBER — Enum
