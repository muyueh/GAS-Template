## PictureFill

### Methods

- getAs(contentType) — Blob
- getBlob() — Blob
- getContentUrl() — String
- getSourceUrl() — String
