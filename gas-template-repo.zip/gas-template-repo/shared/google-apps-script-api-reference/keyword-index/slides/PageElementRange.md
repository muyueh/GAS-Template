## PageElementRange

### Methods

- getPageElements() — PageElement[]
