## ParagraphAlignment

### Properties

- UNSUPPORTED — Enum
- START — Enum
- CENTER — Enum
- END — Enum
- JUSTIFIED — Enum
