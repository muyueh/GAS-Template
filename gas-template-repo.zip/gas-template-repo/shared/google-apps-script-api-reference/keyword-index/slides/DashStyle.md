## DashStyle

### Properties

- UNSUPPORTED — Enum
- SOLID — Enum
- DOT — Enum
- DASH — Enum
- DASH_DOT — Enum
- LONG_DASH — Enum
- LONG_DASH_DOT — Enum
