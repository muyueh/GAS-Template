## ListStyle

### Methods

- applyListPreset(listPreset) — ListStyle
- getGlyph() — String
- getList() — List
- getNestingLevel() — Integer
- isInList() — Boolean
- removeFromList() — ListStyle
