## AutofitType

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- TEXT_AUTOFIT — Enum
- SHAPE_AUTOFIT — Enum
