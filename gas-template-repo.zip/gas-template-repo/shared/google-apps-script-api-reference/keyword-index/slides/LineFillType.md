## LineFillType

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- SOLID — Enum
