## NotesMaster

### Methods

- getGroups() — Group[]
- getImages() — Image[]
- getLines() — Line[]
- getObjectId() — String
- getPageElementById(id) — PageElement
- getPageElements() — PageElement[]
- getPlaceholder(placeholderType) — PageElement
- getPlaceholder(placeholderType, placeholderIndex) — PageElement
- getPlaceholders() — PageElement[]
- getShapes() — Shape[]
- getSheetsCharts() — SheetsChart[]
- getTables() — Table[]
- getVideos() — Video[]
- getWordArts() — WordArt[]
