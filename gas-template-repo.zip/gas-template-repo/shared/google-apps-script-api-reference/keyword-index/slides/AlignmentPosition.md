## AlignmentPosition

### Properties

- CENTER — Enum
- HORIZONTAL_CENTER — Enum
- VERTICAL_CENTER — Enum
