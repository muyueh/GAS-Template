## ArrowStyle

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- STEALTH_ARROW — Enum
- FILL_ARROW — Enum
- FILL_CIRCLE — Enum
- FILL_SQUARE — Enum
- FILL_DIAMOND — Enum
- OPEN_ARROW — Enum
- OPEN_CIRCLE — Enum
- OPEN_SQUARE — Enum
- OPEN_DIAMOND — Enum
