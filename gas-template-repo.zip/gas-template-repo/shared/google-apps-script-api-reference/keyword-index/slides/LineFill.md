## LineFill

### Methods

- getFillType() — LineFillType
- getSolidFill() — SolidFill
- setSolidFill(color) — void
- setSolidFill(color, alpha) — void
- setSolidFill(red, green, blue) — void
- setSolidFill(red, green, blue, alpha) — void
- setSolidFill(hexString) — void
- setSolidFill(hexString, alpha) — void
- setSolidFill(color) — void
- setSolidFill(color, alpha) — void
