## ConnectionSite

### Methods

- getIndex() — Integer
- getPageElement() — PageElement
