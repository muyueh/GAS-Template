## AffineTransform

### Methods

- getScaleX() — Number
- getScaleY() — Number
- getShearX() — Number
- getShearY() — Number
- getTranslateX() — Number
- getTranslateY() — Number
- toBuilder() — AffineTransformBuilder
