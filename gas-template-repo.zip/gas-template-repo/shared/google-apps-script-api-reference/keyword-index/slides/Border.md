## Border

### Methods

- getDashStyle() — DashStyle
- getLineFill() — LineFill
- getWeight() — Number
- isVisible() — Boolean
- setDashStyle(style) — Border
- setTransparent() — Border
- setWeight(points) — Border
