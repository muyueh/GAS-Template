## [Alignment](https://developers.google.com/apps-script/reference/forms/alignment)

### Properties

| Property |  Type  |                  Description                   |
|----------|--------|------------------------------------------------|
| `LEFT`   | `Enum` | Align the image to the left side of the form.  |
| `CENTER` | `Enum` | Align the image to the center of the form.     |
| `RIGHT`  | `Enum` | Align the image to the right side of the form. |
