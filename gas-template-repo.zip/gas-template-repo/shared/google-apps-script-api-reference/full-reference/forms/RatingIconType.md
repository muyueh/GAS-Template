## [RatingIconType](https://developers.google.com/apps-script/reference/forms/rating-icon-type)

### Properties

|  Property  |  Type  |   Description    |
|------------|--------|------------------|
| `STAR`     | `Enum` | A star icon.     |
| `HEART`    | `Enum` | A heart icon.    |
| `THUMB_UP` | `Enum` | A thumb up icon. |
