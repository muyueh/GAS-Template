## [VerticalAlignment](https://developers.google.com/apps-script/reference/document/vertical-alignment)

### Properties

| Property |  Type  |         Description          |
|----------|--------|------------------------------|
| `BOTTOM` | `Enum` | The bottom-alignment option. |
| `CENTER` | `Enum` | The center-alignment option. |
| `TOP`    | `Enum` | The top-alignment option.    |
