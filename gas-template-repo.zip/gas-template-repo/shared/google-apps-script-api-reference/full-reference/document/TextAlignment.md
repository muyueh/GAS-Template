## [TextAlignment](https://developers.google.com/apps-script/reference/document/text-alignment)

### Properties

|   Property    |  Type  |           Description           |
|---------------|--------|---------------------------------|
| `NORMAL`      | `Enum` | The normal text alignment.      |
| `SUPERSCRIPT` | `Enum` | The superscript text alignment. |
| `SUBSCRIPT`   | `Enum` | The subscript text alignment.   |
