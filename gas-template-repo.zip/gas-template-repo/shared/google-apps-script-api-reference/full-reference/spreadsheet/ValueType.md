## [ValueType](https://developers.google.com/apps-script/reference/spreadsheet/value-type)

### Properties

| Property |  Type  |                   Description                   |
|----------|--------|-------------------------------------------------|
| `IMAGE`  | `Enum` | The value type when the cell contains an image. |
