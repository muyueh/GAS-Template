## [BooleanCriteria](https://developers.google.com/apps-script/reference/spreadsheet/boolean-criteria)

### Properties

|             Property              |  Type  |                                     Description                                     |
|-----------------------------------|--------|-------------------------------------------------------------------------------------|
| `CELL_EMPTY`                      | `Enum` | The criteria is met when a cell is empty.                                           |
| `CELL_NOT_EMPTY`                  | `Enum` | The criteria is met when a cell is not empty.                                       |
| `DATE_AFTER`                      | `Enum` | The criteria is met when a date is after the given value.                           |
| `DATE_BEFORE`                     | `Enum` | The criteria is met when a date is before the given value.                          |
| `DATE_EQUAL_TO`                   | `Enum` | The criteria is met when a date is equal to the given value.                        |
| `DATE_NOT_EQUAL_TO`               | `Enum` | The criteria is met when a date is not equal to the given value.                    |
| `DATE_AFTER_RELATIVE`             | `Enum` | The criteria is met when a date is after the relative date value.                   |
| `DATE_BEFORE_RELATIVE`            | `Enum` | The criteria is met when a date is before the relative date value.                  |
| `DATE_EQUAL_TO_RELATIVE`          | `Enum` | The criteria is met when a date is equal to the relative date value.                |
| `NUMBER_BETWEEN`                  | `Enum` | The criteria is met when a number that is between the given values.                 |
| `NUMBER_EQUAL_TO`                 | `Enum` | The criteria is met when a number that is equal to the given value.                 |
| `NUMBER_GREATER_THAN`             | `Enum` | The criteria is met when a number that is greater than the given value.             |
| `NUMBER_GREATER_THAN_OR_EQUAL_TO` | `Enum` | The criteria is met when a number that is greater than or equal to the given value. |
| `NUMBER_LESS_THAN`                | `Enum` | The criteria is met when a number that is less than the given value.                |
| `NUMBER_LESS_THAN_OR_EQUAL_TO`    | `Enum` | The criteria is met when a number that is less than or equal to the given value.    |
| `NUMBER_NOT_BETWEEN`              | `Enum` | The criteria is met when a number that is not between the given values.             |
| `NUMBER_NOT_EQUAL_TO`             | `Enum` | The criteria is met when a number that is not equal to the given value.             |
| `TEXT_CONTAINS`                   | `Enum` | The criteria is met when the input contains the given value.                        |
| `TEXT_DOES_NOT_CONTAIN`           | `Enum` | The criteria is met when the input does not contain the given value.                |
| `TEXT_EQUAL_TO`                   | `Enum` | The criteria is met when the input is equal to the given value.                     |
| `TEXT_NOT_EQUAL_TO`               | `Enum` | The criteria is met when the input is not equal to the given value.                 |
| `TEXT_STARTS_WITH`                | `Enum` | The criteria is met when the input begins with the given value.                     |
| `TEXT_ENDS_WITH`                  | `Enum` | The criteria is met when the input ends with the given value.                       |
| `CUSTOM_FORMULA`                  | `Enum` | The criteria is met when the input makes the given formula evaluate to `true`.      |
