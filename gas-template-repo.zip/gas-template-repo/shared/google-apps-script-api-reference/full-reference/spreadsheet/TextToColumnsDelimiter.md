## [TextToColumnsDelimiter](https://developers.google.com/apps-script/reference/spreadsheet/text-to-columns-delimiter)

### Properties

|  Property   |  Type  |   Description    |
|-------------|--------|------------------|
| `COMMA`     | `Enum` | `","` delimiter. |
| `SEMICOLON` | `Enum` | `";"` delimiter. |
| `PERIOD`    | `Enum` | `"."` delimiter. |
| `SPACE`     | `Enum` | `" "` delimiter. |
