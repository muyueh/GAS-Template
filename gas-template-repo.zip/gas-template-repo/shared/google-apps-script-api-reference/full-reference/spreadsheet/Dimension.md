## [Dimension](https://developers.google.com/apps-script/reference/spreadsheet/dimension)

### Properties

| Property  |  Type  |           Description            |
|-----------|--------|----------------------------------|
| `COLUMNS` | `Enum` | The column (vertical) dimension. |
| `ROWS`    | `Enum` | The row (horizontal) dimension.  |
