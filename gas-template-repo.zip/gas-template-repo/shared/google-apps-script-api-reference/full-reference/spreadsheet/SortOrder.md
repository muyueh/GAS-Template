## [SortOrder](https://developers.google.com/apps-script/reference/spreadsheet/sort-order)

### Properties

|   Property   |  Type  |      Description       |
|--------------|--------|------------------------|
| `ASCENDING`  | `Enum` | Ascending sort order.  |
| `DESCENDING` | `Enum` | Descending sort order. |
