## [AutoFillSeries](https://developers.google.com/apps-script/reference/spreadsheet/auto-fill-series)

### Properties

|      Property      |  Type  |                                                           Description                                                            |
|--------------------|--------|----------------------------------------------------------------------------------------------------------------------------------|
| `DEFAULT_SERIES`   | `Enum` | Default.                                                                                                                         |
| `ALTERNATE_SERIES` | `Enum` | Auto-filling with this setting results in the empty cells in the expanded range being filled with copies of the existing values. |
