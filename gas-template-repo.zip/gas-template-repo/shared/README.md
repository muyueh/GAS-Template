# Shared Snippets

Place any reusable Apps Script helpers or documentation here. Files stored
inside `shared/` can be copied into either Apps Script project when needed.
